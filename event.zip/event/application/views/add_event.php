<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Event</title>

<style>
    .error{
        color:red;
    }
</style>
</head>
<body>
<form action="insert_event" method="post" id="event_form">
<table style="padding:10px 10px; margin: 40px 40px">
    <thead>
        <tr>
            <td>
                <strong>Add Event Page</strong>
            </td>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>
               Event Details  :
            </td>
            <td colspan="2">
                <input type="text" name="event">
                <?php echo form_error('event','<div class="error">', '</div>')?>
            </td>
        </tr>
        <tr>
            <td>
               Start Date :
            </td>
            <td>
                <input type="date" name="start_date">
                <?php echo form_error('start_date','<div class="error">', '</div>')?>
            </td>
        </tr>
        <tr>
            <td>
            Recurrence :
            </td>
            <td>
                Repeat every
                <input type="number" name="r_num" value="1" min='1'>
                <select name="r_option" class="event_types" >
                    <option value="day">Day</option>
                    <option value="week">Week</option>
                </select>
                <?php echo form_error('r_num','<div class="error">', '</div>')?>

            </td>
        </tr>
        <tr style="display: none" class="day_names">
            <td>
            </td>
            <td>
                <strong>Repate On </strong>
                <div>
                    <lable for="sunday"><input type="checkbox" id="sunday" value="sunday" name="day_names[]"> Sunday</lable>
                </div>
                <div>
                    <lable for="monday"><input type="checkbox" id="monday" value="monday" name="day_names[]"> Monday</lable>
                </div>
                <div>
                    <lable for="tuesday"><input type="checkbox" id="tuesday" value="tuesday" name="day_names[]"> Tuesday</lable>
                </div>
                <div>
                    <lable for="wednesday"><input type="checkbox" id="wednesday" value="wednesday" name="day_names[]"> Wednesday</lable>
                </div>
                <div>
                    <lable for="thrusday"><input type="checkbox" id="thrusday" value="thrusday" name="day_names[]"> Thrusday</lable>
                </div>
                <div>
                    <lable for="friday"><input type="checkbox" id="friday" value="friday" name="day_names[]"> Friday</lable>
                </div>
                <div>
                    <lable for="saturday"><input type="checkbox" id="saturday" value="saturday" name="day_names[]"> Saturday</lable>
                </div>
                <?php echo form_error('day_names[]','<div class="error">', '</div>')?>
                
            </td>
        </tr>
        <tr>
            <td>
            Ends After :
            </td>
            <td>
                <input type="number" name="end_r" value="1" min='1'> Occurrences
                <?php echo form_error('end_r','<div class="error">', '</div>')?>

                
            </td>
        </tr>
        <tr>
            <td>
            </td>
            <td>
                <input type="submit" value="submit">
                
            </td>
        </tr>
    </tbody>
</table>




<table border='1' style="padding:10px 10px; margin: 40px 40px">
    <thead>
    <tr>
            <td>
                <strong>Event List</strong>
            </td>
        </tr>
        <tr>
            <td>S.no</td>
            <td>Title</td>
            <td>Start Date</td>
            <td>End Date</td>
            <td>Actions</td>
        </tr>
    </thead>
    <tbody>
    <?php if($event_data){ 
               foreach($event_data as $row){?>
        <tr>
          
            <td><?php echo $row['ID'];?></td>
            <td><?php echo $row['title'];?></td>
            <td><?php echo $row['start_date'];?></td>
            <td><?php echo $row['end_date'];?></td>
            <td>
                <a href="event_delete/<?php echo $row['ID'];?>">Delete</a>
            </td>
           
        </tr>
        <?php }}?>  
    </tbody>
</table>

</form>
</body>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.3/dist/jquery.validate.js"></script>

<script>

    $(document).ready(function(){
        $('body').on('change','.event_types',function(){
            if($(this).val()==="week"){
                $('.day_names').show();
            }else{
                $('.day_names').hide();
            }
        });

        $('#event_form').validate({

            rules:{
                'event':{
                    required : true
                },
                'start_date':{
                    required : true
                },
                'r_num':{
                    required : true
                },
                'day_names[]':{
                    required : true
                },
                'end_r':{
                    required : true
                },
            }

        });

    });
</script>
</html>