<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Main_model extends CI_Model {


    public function insert_info($table='',$data='')
    {
        $this->db->insert($table, $data);
        if($this->db->affected_rows()){
            return true;
        }
        else{
            return false;
        }
    }
    public function get_data($table='',$where='')
    {
        $this->db->select('*');
        $this->db->from($table);
        $this->db->where($where);
        $data=$this->db->get()->result_array();

        if(!empty($data)){
            return $data;
        }else{
            return array();
        }
    }
    public function delete($table='',$where='')
    {
        $data=$this->db->delete($table, $where);
        if($data){
            return true;
        }
        else{
            return false;
        }
    }

}